module.exports = {
    mongoURI: 'mongodb+srv://test:test@lms.ovf9a24.mongodb.net/test?retryWrites=true&w=majority',
    secret:   'somethingsecrethere'
}
